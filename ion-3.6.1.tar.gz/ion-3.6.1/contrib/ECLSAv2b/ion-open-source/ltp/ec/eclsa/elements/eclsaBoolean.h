/*
 eclsaBoolean.h

 Author: Nicola Alessi (nicola.alessi@studio.unibo.it)
 Project Supervisor: Carlo Caini (carlo.caini@unibo.it)

 Copyright (c) 2016, Alma Mater Studiorum, University of Bologna
 All rights reserved.

todo

 * */

#ifndef _ECLSABOOLEAN_H_
#define _ECLSABOOLEAN_H_


#ifdef __cplusplus
extern "C" {
#endif


#define true 1
#define false 0
typedef unsigned char bool;


#ifdef __cplusplus
}
#endif

#endif
